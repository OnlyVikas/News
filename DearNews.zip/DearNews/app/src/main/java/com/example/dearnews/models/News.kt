package com.example.dearnews.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

public class NEWS {

    @SerializedName("status")
    @Expose
    private  String status;
}